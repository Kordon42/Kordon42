const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json")

exports.run = async (client, message, args) => {

  if(message.channel.id !== ayarlar.botkomut) return message.channel.send(`<#${ayarlar.botkomut}> sadece bu kanalda kullanabılır.`)
    if (message.member.roles.cache.has(`${ayarlar.jsrol}`)) 
    return message.channel.send("Zaten \`JavaScript\` Rolüne Sahipsin!").then(message => message.delete({timeout: 1000}))
   
  message.member.roles.add(`${ayarlar.jsrol}`)

  message.delete()
      message.channel.send(`<a:yildiz:848590945212956723> | Başarılı! Javascript Rolü Verildi.`).then(message => message.delete({timeout: 1000}))
      
      client.channels.cache.get(`${ayarlar.rollog}`).send(`**<a:yildiz:848590945212956723> | <@${message.author.id}> Adlı Kullanıcıya \`JavaScript\` Verildi**`)
}
exports.conf = {
  enabled: true,
  guildonly: true,
  aliases: [],
  permLevel: 0
}
exports.help = {
  name: "js"
}
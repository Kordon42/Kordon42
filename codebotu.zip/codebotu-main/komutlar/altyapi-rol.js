const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json")

exports.run = async (client, message, args) => {

  if(message.channel.id !== ayarlar.yetkilikanal) return message.channel.send(`<#${ayarlar.yetkilikanal}> sadece bu kanalda kullanabılır.`)
    if (message.member.roles.cache.has(`${ayarlar.altyapırol}`)) 
    return message.channel.send("Zaten \`Altyapı\` Rolüne Sahipsin!").then(message => message.delete({timeout: 1000}))
   
  message.member.roles.add(`${ayarlar.altyapırol}`)

  message.delete()
      message.channel.send(`<a:yildiz:848590945212956723> | Başarılı! Altyapı Rolü Verildi.`).then(message => message.delete({timeout: 1000}))

      client.channels.cache.get(`${ayarlar.rollog}`).send(`**<a:yildiz:848590945212956723> | <@${message.author.id}> Adlı Kullanıcıya \`Altyapı\` Verildi**`)
}
exports.conf = {
  enabled: true,
  guildonly: true,
  aliases: [],
  permLevel: 0
}
exports.help = {
  name: "altyapı"
}
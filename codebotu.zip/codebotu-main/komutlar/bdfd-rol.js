const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json")

exports.run = async (client, message, args) => {

  if(message.channel.id !== ayarlar.botkomut) return message.channel.send(`<#${ayarlar.botkomut}> sadece bu kanalda kullanabılır.`)
    if (message.member.roles.cache.has(`${ayarlar.bdfdrol}`)) 
    return message.channel.send("Zaten \`BDFD\` Rolüne Sahipsin!").then(message => message.delete({timeout: 1000}))
   
  message.member.roles.add(`${ayarlar.bdfdrol}`)

  message.delete()
      message.channel.send(`<a:yildiz:848590945212956723> | Başarılı! BDFD Rolü Verildi.`).then(message => message.delete({timeout: 1000}))
      
      client.channels.cache.get(`${ayarlar.rollog}`).send(`**<a:yildiz:848590945212956723> | <@${message.author.id}> Adlı Kullanıcıya \`BDFD\` Verildi**`)
}
exports.conf = {
  enabled: true,
  guildonly: true,
  aliases: [],
  permLevel: 0
}
exports.help = {
  name: "bdfd"
}
const Discord = require(`discord.js`);
const db = require('quick.db');

exports.run = async(client, message, args) => {

    let kişi = message.mentions.users.first()
if(!args[0]) {
    const javaScript = await db.fetch(`javascript_${message.author.id}.${message.guild.id}`)
    const bdfd = await db.fetch(`bdfd_${message.author.id}.${message.guild.id}`)
    const altyapı = await db.fetch(`altyapi_${message.author.id}.${message.guild.id}`)
    const soulcastle1 = new Discord.MessageEmbed()
    .setThumbnail(message.author.avatarURL())
    .setTimestamp()
    .setFooter(`${message.author.tag} Tarafından İstendi.`)
    .setDescription(`**${message.author} İsimli Yetkilinin İstatistikleri**
    **▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬**
    **<a:twitchbit:848525534996463636> Toplam \`${javaScript ? javaScript : '0'}\` JavaScript Komutu Paylaşmışın.**
    **<a:twitchbit:848525534996463636> Toplam \`${bdfd ? bdfd : '0'}\` BDFD Komutu Paylaşmışın.**
    **<a:twitchbit:848525534996463636> Toplam \`${altyapı ? altyapı : '0'}\` Altyapı Paylaşmışın.**
    **▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬**`)
    message.channel.send(soulcastle1)}
if(kişi) {
    const javaScript2 = await db.fetch(`javascript_${kişi.id}.${message.guild.id}`)
    const bdfd2 = await db.fetch(`bdfd_${message.author.id}.${message.guild.id}`)
    const altyapı2 = await db.fetch(`altyapi_${message.author.id}.${message.guild.id}`)
    const soulcastle = new Discord.MessageEmbed()
    .setAuthor(kişi.username, kişi.avatarURL)
    .setThumbnail(message.mentions.users.first().avatarURL())
    .setTimestamp()
    .setFooter(`${message.author.tag} Tarafından İstendi.`)
    .setDescription(`**Yetkilinin İstatistikleri**
    **▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬**
    **<a:twitchbit:848525534996463636> Toplam \`${javaScript2 ? javaScript2 : '0'}\` JavaScript Komutu Paylaşmışsın.**
    **<a:twitchbit:848525534996463636> Toplam \`${bdfd2 ? bdfd2 : '0'}\` BDFD Komutu Paylaşmış.**
    **<a:twitchbit:848525534996463636> Toplam \`${altyapı2 ? altyapı2 : '0'}\` Altyapı Paylaşmış.**
    **▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬**`)
    message.channel.send(soulcastle)}  
};
exports.conf = {
 enabled: true,
 guildOnly: false,
 aliases: [],
 permLevel: 0,
};
exports.help = {
 name: 'stats'
};
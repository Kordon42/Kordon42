const Discord = require("discord.js");
const db = require("quick.db")
const ayarlar = require("../ayarlar.json")

exports.run = async(client, message, args) => {

    if(message.channel.id !== ayarlar.yetkilikanal) return message.channel.send(`<#${ayarlar.yetkilikanal}> sadece bu kanalda kullanabılır.`)

    let kodisimi = args[0]
let kodlink = args[1]

if(!kodisimi) return message.channel.send("Altyapı İsmini Yaz.")
if(!kodlink) return message.channel.send("Altyapının Linki.")

message.delete()

message.channel.send("✅ **|** Altyapınız Sisteme Eklendi.").then(message => message.delete({timeout: 1000}))

message.guild.channels.create(kodisimi, {
    type: "text",
    parent: "KATEGORİ İD"//KATEGORİ İD
  }).then(channel => {
    let soulcastle = new Discord.MessageEmbed()
    .setAuthor(`${message.guild.name} - Altyapı Paylaşıldı`)
    .addField("<:dev:787012053235793930> Yetkili Bilgileri", `<:dev:787012053235793930> Yetkili İsim \`${message.author.tag}\` \n <:dev:787012053235793930> Yetkili ID \`${message.author.id}\``)
    .addField("<a:elmas:848590371486957629> Kod Bilgileri", `<a:elmas:848590371486957629> Kod İsmi \`${kodisimi}\` \n<a:elmas:848590371486957629> Kod Kategorisi \`Altyapı\` `)
    .setColor("BLUE")
    
    
    client.channels.cache.get(ayarlar.codelog).send(soulcastle)
    db.add(`altyapi_${message.author.id}.${message.guild.id}`, 1)

    const castle = new Discord.MessageEmbed()
    .setAuthor(`Kod Hakkında`)
    .setDescription(`
    <a:UrlGif:751325009427038248> Yetkili İsim \`${message.author.tag}\`
    <a:UrlGif:751325009427038248>  Kod İsmi \`${kodisimi}\`
    <a:UrlGif:751325009427038248>  Kod Linki [Tıkla!](${kodlink})
    `)
    .setTimestamp()
    .setColor("BLUE")
    channel.send(castle)
  
  })

  
}
exports.conf = {
	enabled: true,
	guildOnly: false,
	aliases:[],
	permlevel: 0
};

exports.help = {
	name: "altyapı-paylaş"
}
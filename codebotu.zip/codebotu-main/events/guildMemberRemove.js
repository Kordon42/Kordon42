const Discord = require('discord.js');
module.exports = member => {
};//LORDCREATİVE